---
title: 'Protected: Resources'
author: Iulian
type: page
date: 2013-05-05T19:10:35+00:00
cleanretina_sidebarlayout:
  - right-sidebar

---
Pareto principle

<a href="https://en.wikipedia.org/wiki/Pareto_principle" target="_blank">https://en.wikipedia.org/wiki/Pareto_principle</a>

  * 80% of a company&#8217;s profits come from 20% of its customers
  * 80% of a company&#8217;s complaints come from 20% of its customers
  * 80% of a company&#8217;s profits come from 20% of the time its staff spend
  * 80% of a company&#8217;s sales come from 20% of its products
  * 80% of a company&#8217;s sales are made by 20% of its sales staf

&nbsp;

&nbsp;