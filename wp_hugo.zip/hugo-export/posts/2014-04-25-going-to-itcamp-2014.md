---
title: Going to ITCamp 2014
author: Iulian
type: post
date: 2014-04-25T18:08:25+00:00
url: /2014/04/going-to-itcamp-2014/
categories:
  - Uncategorized
format: image

---
[<img src="http://www.iuliantabara.com/wp-content/uploads/2014/04/ITCamp-attendee-banner.jpg" alt="ITCamp-attendee-banner" width="250" height="250" class="aligncenter size-full wp-image-432" srcset="https://www.iuliantabara.com/wp-content/uploads/2014/04/ITCamp-attendee-banner.jpg 250w, https://www.iuliantabara.com/wp-content/uploads/2014/04/ITCamp-attendee-banner-150x150.jpg 150w" sizes="(max-width: 250px) 100vw, 250px" />][1]

 [1]: http://www.iuliantabara.com/wp-content/uploads/2014/04/ITCamp-attendee-banner.jpg