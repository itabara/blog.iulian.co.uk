---
title: Vienna Philharmonic New Year’s Concert 2008
author: Iulian
type: post
date: 2008-01-01T11:53:51+00:00
url: /2008/01/vienna-philharmonic-new-years-concert-2008/
categories:
  - Misc
tags:
  - Vienna

---
See also:
  
[Vienna Philharmonic New Year&#8217;s Concert 2007][1]

 [1]: http://www.iuliantabara.com/2007/01/vienna-philharmonic-new-years-concert-2007/ "Vienna Philharmonic New Year’s Concert 2007"