---
title: 'Private: SonarQube and'
author: Iulian
type: post
date: 2016-03-01T18:33:38+00:00
draft: true
private: true
url: /2016/03/sonarqube-and/
categories:
  - Uncategorized
tags:
  - SonarQube
  - Technical debt

---
<p style="text-align: justify;">
  <a href="https://www.iuliantabara.com/2016/02/dealing-with-technical-debt/" target="_blank">Technical debt</a> saps productivity by making code hard to understand, fragile, difficult to validate, and creates unplanned work that blocks progress. <a href="http://www.sonarqube.org/" target="_blank">SonarQube </a>is the de-facto open source tool to manage down technical debt.
</p>

<p style="text-align: justify;">
  Additional links:
</p>

<li style="text-align: justify;">
  <a href="http://docs.sonarqube.org/display/HOME/Developers'+Seven+Deadly+Sins" target="_blank">http://docs.sonarqube.org/display/HOME/Developers&#8217;+Seven+Deadly+Sins</a>
</li>