---
title: 'Private: MongoDB – Map Reduce'
author: Iulian
type: post
date: 2016-01-08T17:17:00+00:00
draft: true
private: true
url: /2016/01/mongodb-map-reduce/
categories:
  - NoSQL
tags:
  - mongodb

---
