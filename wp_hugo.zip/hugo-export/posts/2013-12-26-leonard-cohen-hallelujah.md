---
title: Leonard Cohen – Hallelujah
author: Iulian
type: post
date: 2013-12-26T10:33:36+00:00
url: /2013/12/leonard-cohen-hallelujah/
categories:
  - Misc
tags:
  - Leonard Cohen

---
**Hallelujah**

I&#8217;ve heard there was a secret chord
  
That David played, and it pleased the Lord
  
But you don&#8217;t really care for music, do you?
  
It goes like this
  
The fourth, the fifth
  
The minor fall, the major lift
  
The baffled king composing Hallelujah

Hallelujah, Hallelujah
  
Hallelujah, Hallelujah

Your faith was strong but you needed proof
  
You saw her bathing on the roof
  
Her beauty in the moonlight overthrew you
  
She tied you to a kitchen chair
  
She broke your throne, and she cut your hair
  
And from your lips she drew the Hallelujah

Hallelujah, Hallelujah
  
Hallelujah, Hallelujah

Baby I have been here before
  
I know this room, I&#8217;ve walked this floor
  
I used to live alone before I knew you.
  
I&#8217;ve seen your flag on the marble arch
  
Love is not a victory march
  
It&#8217;s a cold and it&#8217;s a broken Hallelujah

Hallelujah, Hallelujah
  
Hallelujah, Hallelujah

There was a time when you let me know
  
What&#8217;s really going on below
  
But now you never show it to me, do you?
  
And remember when I moved in you
  
The holy dove was moving too
  
And every breath we drew was Hallelujah

Hallelujah, Hallelujah
  
Hallelujah, Hallelujah

Maybe there’s a God above
  
But all I’ve ever learned from love
  
Was how to shoot at someone who outdrew you
  
It’s not a cry you can hear at night
  
It’s not somebody who has seen the light
  
It’s a cold and it’s a broken Hallelujah

Hallelujah, Hallelujah
  
Hallelujah, Hallelujah

You say I took the name in vain
  
I don&#8217;t even know the name
  
But if I did, well, really, what&#8217;s it to you?
  
There&#8217;s a blaze of light in every word
  
It doesn&#8217;t matter which you heard
  
The holy or the broken Hallelujah

Hallelujah, Hallelujah
  
Hallelujah, Hallelujah

I did my best, it wasn&#8217;t much
  
I couldn&#8217;t feel, so I tried to touch
  
I&#8217;ve told the truth, I didn&#8217;t come to fool you
  
And even though it all went wrong
  
I&#8217;ll stand before the Lord of Song
  
With nothing on my tongue but Hallelujah

Hallelujah, Hallelujah
  
Hallelujah, Hallelujah
  
Hallelujah, Hallelujah
  
Hallelujah, Hallelujah
  
Hallelujah, Hallelujah
  
Hallelujah, Hallelujah
  
Hallelujah, Hallelujah
  
Hallelujah, Hallelujah
  
Hallelujah 

<a href="http://www.azlyrics.com/lyrics/leonardcohen/hallelujah.html" title="source" target="_blank"></a>