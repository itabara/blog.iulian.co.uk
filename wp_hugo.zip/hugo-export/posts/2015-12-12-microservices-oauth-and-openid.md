---
title: Microservices – OAuth and OpenID
author: Iulian
type: post
date: 2015-12-12T12:48:03+00:00
url: /2015/12/microservices-oauth-and-openid/
categories:
  - Architecture

---
