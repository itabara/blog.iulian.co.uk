---
title: 'Private: http://insidethecpu.com/'
author: Iulian
type: post
date: 2015-11-18T20:39:20+00:00
draft: true
private: true
url: /2015/11/httpinsidethecpu-com/
categories:
  - Uncategorized

---
http://insidethecpu.com/ -> c# microservices