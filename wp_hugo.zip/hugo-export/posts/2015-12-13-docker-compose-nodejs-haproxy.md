---
title: 'Private: docker-compose-nodejs-haproxy/'
author: Iulian
type: post
date: 2015-12-13T13:24:38+00:00
draft: true
private: true
url: /2015/12/docker-compose-nodejs-haproxy/
categories:
  - Uncategorized

---
http://blog.hypriot.com/post/docker-compose-nodejs-haproxy/