---
title: 'Private: http://logcorner.wordpress.com/2013/09/09/asp-net-custom-membership-password-encoding-and-decoding-based-on-salt-key-sha-1-cryptography/'
author: Iulian
type: post
date: 2014-04-30T19:08:19+00:00
draft: true
private: true
url: /2014/04/httplogcorner-wordpress-com20130909asp-net-custom-membership-password-encoding-and-decoding-based-on-salt-key-sha-1-cryptography/
categories:
  - Uncategorized

---
http://balajidotnet.wordpress.com/2014/03/11/sql-server-select-results-as-string-separated-with/
  
http://balajidotnet.wordpress.com/2014/03/20/oops-concepts/
  
http://www.c-sharpcorner.com/UploadFile/abhikumarvatsa/various-ways-to-pass-data-from-controller-to-view-in-mvc/