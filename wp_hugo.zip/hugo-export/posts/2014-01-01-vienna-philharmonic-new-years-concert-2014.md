---
title: Vienna Philharmonic New Year’s Concert 2014
author: Iulian
type: post
date: 2014-01-01T11:44:57+00:00
url: /2014/01/vienna-philharmonic-new-years-concert-2014/
categories:
  - Misc
tags:
  - Vienna

---
See also:
  
[Vienna Philharmonic New Year’s Concert 2013][1]
  
[Vienna Philharmonic New Year’s Concert 2012][2]
  
[Vienna Philharmonic New Year’s Concert 2011][3]
  
[Vienna Philharmonic New Year’s Concert 2010][4]
  
[Vienna Philharmonic New Year&#8217;s Concert 2009][5]
  
[Vienna Philharmonic New Year&#8217;s Concert 2008][6]
  
[Vienna Philharmonic New Year&#8217;s Concert 2007][7]

 [1]: http://www.iuliantabara.com/2013/01/vienna-philharmonic-new-years-concert-2013/ "Vienna Philharmonic New Year’s Concert 2013"
 [2]: http://www.iuliantabara.com/2012/01/vienna-philharmonic-new-years-concert-2012/ "Vienna Philharmonic New Year’s Concert 2012"
 [3]: http://www.iuliantabara.com/2011/01/vienna-philharmonic-new-years-concert-2011/ "Vienna Philharmonic New Year’s Concert 2011"
 [4]: http://www.iuliantabara.com/2010/01/vienna-philharmonic-new-years-concert-2010/ "Vienna Philharmonic New Year’s Concert 2010"
 [5]: http://www.iuliantabara.com/2009/01/vienna-philharmonic-new-years-concert-2009/ "Vienna Philharmonic New Year’s Concert 2009"
 [6]: http://www.iuliantabara.com/2008/01/vienna-philharmonic-new-years-concert-2008/ "Vienna Philharmonic New Year’s Concert 2008"
 [7]: http://www.iuliantabara.com/2007/01/vienna-philharmonic-new-years-concert-2007/ "Vienna Philharmonic New Year’s Concert 2007"