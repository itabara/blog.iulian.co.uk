---
title: SONAR CODE QUALITY
author: Iulian
type: post
date: 2015-04-25T17:48:34+00:00
url: /2015/04/sonar-code-quality/
categories:
  - Uncategorized

---
Sonar
  
https://confluence.jetbrains.com/display/TW/SonarQube+Integration