---
title: Vienna Philharmonic New Year’s Concert 2007
author: Iulian
type: post
date: 2007-01-01T11:55:06+00:00
url: /2007/01/vienna-philharmonic-new-years-concert-2007/
categories:
  - Misc
tags:
  - Vienna

---
