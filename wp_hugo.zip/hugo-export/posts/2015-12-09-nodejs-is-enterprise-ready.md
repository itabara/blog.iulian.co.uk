---
title: 'Private: Node.js is Enterprise Ready'
author: Iulian
type: post
date: 2015-12-09T17:32:32+00:00
draft: true
private: true
url: /2015/12/nodejs-is-enterprise-ready/
categories:
  - Uncategorized

---
https://resources.risingstack.com/nodejs-is-enterprise-ready-09-11-2015.pdf