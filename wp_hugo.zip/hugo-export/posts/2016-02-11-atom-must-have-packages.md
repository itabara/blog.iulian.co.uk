---
title: Atom must have packages
author: Iulian
type: post
date: 2016-02-11T21:42:18+00:00
url: /2016/02/atom-must-have-packages/
categories:
  - Setup environment
tags:
  - atom

---
Below the must have packages for atom editor:

  * <a href="https://atom.io/packages/atom-alignment" target="_blank">atom-alignment</a>
  * <a href="https://atom.io/packages/jshint" target="_blank">jshint</a>
  * <a href="https://atom.io/packages/advanced-open-file" target="_blank">advanced-open-file</a>
  * <a href="https://atom.io/packages/emmet" target="_blank">emmet</a> 
      * <a href="http://docs.emmet.io/cheat-sheet/" target="_blank">cheat-sheet</a>
  * <a href="https://atom.io/packages/todo-show" target="_blank">todo-show</a>
  * <a href="https://atom.io/packages/project-manager" target="_blank">project-manager</a> 
      * <a href="https://atom.io/packages/open-recent" target="_blank">open-recent</a>
  * <a href="https://atom.io/packages/highlight-selected" target="_blank">highlight-selected</a> &#8211; highlight other text that is the same in your document (like sublime does)
  * <a href="https://atom.io/packages/less-than-slash" target="_blank">less-than-slash</a>
  * <a href="https://atom.io/packages/atom-beautify" target="_blank">atom-beautify</a>
  * <a href="https://atom.io/packages/pigments" target="_blank">pigments</a>
  * <a href="https://atom.io/packages/file-icons" target="_blank">file-icons</a>
  * <a href="https://atom.io/packages/color-picker" target="_blank">color-picker</a>

To be updated.