---
title: Coderetreat
author: Iulian
type: post
date: 2015-05-30T07:43:38+00:00
url: /2015/05/coderetreat/
categories:
  - Uncategorized

---
Coderetreat is a day-long, intensive practice event, focusing on the fundamentals of software development and design. By providing developers the opportunity to take part in focused practice, away from the pressures of &#8216;getting things done&#8217;, the coderetreat format has proven itself to be a highly effective means of skill improvement. Practicing the basic principles of modular and object-oriented design, developers can improve their ability to write code that minimizes the cost of change over time.

http://coderetreat.org/about