---
title: 'Private: http://nilsnaegele.com/codeedge/cleancode.html'
author: Iulian
type: post
date: 2014-12-22T20:50:15+00:00
draft: true
private: true
url: /2014/12/httpnilsnaegele-comcodeedgecleancode-html/
categories:
  - Source code

---
http://nilsnaegele.com/codeedge/cleancode.html