---
title: Links of the week
author: Iulian
type: post
date: 2017-01-09T14:34:14+00:00
url: /2017/01/links-of-the-week/
categories:
  - Uncategorized
tags:
  - "Today's links"

---
  1. ECMAScript 6: <https://kangax.github.io/compat-table/es6/> -> Compatibility of your javascript with ES6. I use [Google Chrome Canary][1] (currently 97% compatible).
  2. [http://scottjehl.github.io/picturefill/ -> ][2][picture][3] <span class="_Tgc"><b>polyfill</b></span>. Deliver appropriate image size based on client conditions (screensize, viewport, etc).
  3. lsof -i :22
  4. SSL is not an option. How to achieve A+ score <https://michael.lustfield.net/nginx/getting-a-perfect-ssl-labs-score>
  5. Convert crt to pfx: openssl pkcs12 -export -out domain.name.pfx -inkey domain.name.key -in domain.name.crt>

 [1]: https://www.google.com/chrome/browser/canary.html
 [2]: http://scottjehl.github.io/picturefill/
 [3]: https://html.spec.whatwg.org/multipage/embedded-content.html#embedded-content