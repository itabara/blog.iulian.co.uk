---
title: Zsh and themes into Linux Console
author: Iulian
type: post
date: 2015-12-13T21:22:19+00:00
url: /2015/12/zsh-and-themes-into-linux-console/
categories:
  - Linux

---
    apt-get install -y zsh git-core
    sh -c "$(curl -fsSL https://raw.github.com/robbyrussell/oh-my-zsh/master/tools/install.sh)"