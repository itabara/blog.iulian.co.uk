---
title: 97 Things Every Programmer Should Know
author: Iulian
type: post
date: 2015-10-06T17:24:09+00:00
url: /2015/10/97-things-every-programmer-should-know/
categories:
  - Software development
tags:
  - "Today's links"

---
If you&#8217;re the actor in the Development  Scene, please read <a href="http://programmer.97things.oreilly.com/wiki/index.php/97_Things_Every_Programmer_Should_Know" target="_blank">97 Things Every Programmer Should Know</a>