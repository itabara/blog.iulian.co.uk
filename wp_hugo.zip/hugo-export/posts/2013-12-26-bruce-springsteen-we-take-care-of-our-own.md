---
title: Bruce Springsteen – We Take Care Of Our Own
author: Iulian
type: post
date: 2013-12-26T17:51:22+00:00
url: /2013/12/bruce-springsteen-we-take-care-of-our-own/
categories:
  - Misc
tags:
  - Bruce Springsteen

---
**We Take Care Of Our Own**

I&#8217;ve been knockin&#8217; on the door that holds the throne
  
I&#8217;ve been lookin&#8217; for the map that leads me home
  
I&#8217;ve been stumblin&#8217; on good hearts turned to stone
  
The road of good intentions has gone dry as bone
  
We take care of our own
  
We take care of our own
  
Wherever this flag&#8217;s flown
  
We take care of our own

From Chicago to New Orleans
  
From the muscle to the bone
  
From the shotgun shack to the Superdome
  
We yelled &#8220;help&#8221; but the cavalry stayed home
  
There ain&#8217;t no-one hearing the bugle blown
  
We take care of our own
  
We take care of our own
  
Wherever this flag&#8217;s flown
  
We take care of our own

Where the eyes, the eyes with the will to see
  
Where the hearts, that run over with mercy
  
Where&#8217;s the love that has not forsaken me
  
Where&#8217;s the work that set my hands, my soul free
  
Where&#8217;s the spirit that&#8217;ll reign, reign over me
  
Where&#8217;s the promise, from sea to shining sea
  
Where&#8217;s the promise, from sea to shining sea
  
Wherever this flag is flown
  
Wherever this flag is flown
  
Wherever this flag is flown

We take care of our own
  
We take care of our own
  
Wherever this flag&#8217;s flown
  
We take care of our own
  
We take care of our own
  
We take care of our own
  
Wherever this flag&#8217;s flown
  
We take care of our own