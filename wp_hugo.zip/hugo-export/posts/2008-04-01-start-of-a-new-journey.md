---
title: Start of a new journey
author: Iulian
type: post
date: 2008-04-01T20:08:04+00:00
url: /2008/04/start-of-a-new-journey/
categories:
  - Soul

---
Today was my first day at <a href="http://www.webfusion.co.uk" target="_blank">Webfusion</a>.