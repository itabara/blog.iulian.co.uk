---
title: Captain Philips
author: Iulian
type: post
date: 2014-01-26T21:15:46+00:00
url: /2014/01/captain-philips/
categories:
  - Movies

---
Captain Richard Phillips: &#8220;_Listen up, we have been boarded by armed pirates. If they find you, remember, you know this ship, they don&#8217;t. Stick together and we&#8217;ll be all right. Good luck._&#8221;

[<img src="http://www.iuliantabara.com/wp-content/uploads/2014/01/captain-phillips-blu-ray-cover-whysoblu-848x1024.jpg" alt="captain-phillips-blu-ray-cover-whysoblu-848x1024" width="848" height="1024" class="aligncenter size-full wp-image-425" srcset="https://www.iuliantabara.com/wp-content/uploads/2014/01/captain-phillips-blu-ray-cover-whysoblu-848x1024.jpg 848w, https://www.iuliantabara.com/wp-content/uploads/2014/01/captain-phillips-blu-ray-cover-whysoblu-848x1024-248x300.jpg 248w, https://www.iuliantabara.com/wp-content/uploads/2014/01/captain-phillips-blu-ray-cover-whysoblu-848x1024-662x800.jpg 662w" sizes="(max-width: 848px) 100vw, 848px" />][1]

 [1]: http://www.iuliantabara.com/wp-content/uploads/2014/01/captain-phillips-blu-ray-cover-whysoblu-848x1024.jpg