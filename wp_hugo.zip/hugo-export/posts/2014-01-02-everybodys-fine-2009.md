---
title: Everybody‘s Fine (2009)
author: Iulian
type: post
date: 2014-01-02T16:34:21+00:00
url: /2014/01/everybodys-fine-2009/
categories:
  - Movies
tags:
  - Adventure
  - Drama

---
&#8220;_I&#8217;ll take plenty of pictures and I&#8217;ll bring home the news._&#8221; &#8211; Frank
  

  
[<img src="http://www.iuliantabara.com/wp-content/uploads/2014/01/65688048.jpg" alt="65688048" width="388" height="500" class="aligncenter size-full wp-image-401" srcset="https://www.iuliantabara.com/wp-content/uploads/2014/01/65688048.jpg 388w, https://www.iuliantabara.com/wp-content/uploads/2014/01/65688048-232x300.jpg 232w" sizes="(max-width: 388px) 100vw, 388px" />][1]

 [1]: http://www.iuliantabara.com/wp-content/uploads/2014/01/65688048.jpg