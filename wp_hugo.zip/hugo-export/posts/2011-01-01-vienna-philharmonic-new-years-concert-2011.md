---
title: Vienna Philharmonic New Year’s Concert 2011
author: Iulian
type: post
date: 2011-01-01T11:47:37+00:00
url: /2011/01/vienna-philharmonic-new-years-concert-2011/
categories:
  - Misc
tags:
  - Vienna

---
See also:
  
[Vienna Philharmonic New Year’s Concert 2010][1]
  
[Vienna Philharmonic New Year&#8217;s Concert 2009][2]
  
[Vienna Philharmonic New Year&#8217;s Concert 2008][3]
  
[Vienna Philharmonic New Year&#8217;s Concert 2007][4]

 [1]: http://www.iuliantabara.com/2010/01/vienna-philharmonic-new-years-concert-2010/ "Vienna Philharmonic New Year’s Concert 2010"
 [2]: http://www.iuliantabara.com/2009/01/vienna-philharmonic-new-years-concert-2009/ "Vienna Philharmonic New Year’s Concert 2009"
 [3]: http://www.iuliantabara.com/2008/01/vienna-philharmonic-new-years-concert-2008/ "Vienna Philharmonic New Year’s Concert 2008"
 [4]: http://www.iuliantabara.com/2007/01/vienna-philharmonic-new-years-concert-2007/ "Vienna Philharmonic New Year’s Concert 2007"