---
title: Links of the week
author: Iulian
type: post
date: 2017-04-09T07:14:49+00:00
url: /2017/04/links-of-the-week-2/
categories:
  - Uncategorized
tags:
  - "Today's links"

---
  1. git standup -d 1000 via <https://github.com/kamranahmedse/git-standup>
  2. Free ssl with let&#8217;s encrypt with nginx <https://www.digitalocean.com/community/tutorials/how-to-secure-nginx-with-let-s-encrypt-on-ubuntu-16-04>
  3. Still valid <https://codahale.com/how-to-safely-store-a-password/>
  4. <http://www.adhikary.net/post/cygwin-zsh-solarized-apt-cyg/>
  5. <https://github.com/powerline/fonts>
  6. https://blog.alexellis.io/jenkins-2-0-first-impressions/
  7. http://rustamagasanov.com/blog/2016/02/23/dockerize-your-project-part-1-registry-and-jenkins-setup/
  8. http://rustamagasanov.com/blog/2016/02/24/dockerize-your-project-part-2-building-rails-and-postgres-images-with-docker-compose/
  9. https://blog.florianlopes.io/host-multiple-websites-on-single-host-docker/
 10. https://blog.codecentric.de/en/2015/10/continuous-integration-platform-using-docker-container-jenkins-sonarqube-nexus-gitlab/
 11. https://discourse.osmc.tv/t/how-to-install-couchpotato-and-sickrage-on-raspberry-pi/10788/16
 12. http://immutables.pl/2015/12/12/tmux-powerline-zsh-osx/