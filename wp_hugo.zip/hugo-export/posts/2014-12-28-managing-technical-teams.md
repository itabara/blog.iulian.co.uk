---
title: 'Private: Managing technical teams'
author: Iulian
type: post
date: 2014-12-28T09:37:55+00:00
draft: true
private: true
url: /2014/12/managing-technical-teams/
categories:
  - Uncategorized

---
http://sqlblog.com/blogs/andy_leonard/archive/2011/04/06/managing-technical-teams-series-landing-page.aspx