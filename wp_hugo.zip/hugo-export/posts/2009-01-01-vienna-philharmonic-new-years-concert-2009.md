---
title: Vienna Philharmonic New Year’s Concert 2009
author: Iulian
type: post
date: 2009-01-01T11:51:50+00:00
url: /2009/01/vienna-philharmonic-new-years-concert-2009/
categories:
  - Misc
tags:
  - Vienna

---
See also:
  
[Vienna Philharmonic New Year&#8217;s Concert 2008][1]
  
[Vienna Philharmonic New Year&#8217;s Concert 2007][2]

 [1]: http://www.iuliantabara.com/2008/01/vienna-philharmonic-new-years-concert-2008/ "Vienna Philharmonic New Year’s Concert 2008"
 [2]: http://www.iuliantabara.com/2007/01/vienna-philharmonic-new-years-concert-2007/ "Vienna Philharmonic New Year’s Concert 2007"