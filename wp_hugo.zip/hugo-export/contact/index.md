---
title: Contact
author: Iulian
type: page
date: 2013-04-10T20:18:22+00:00
cleanretina_sidebarlayout:
  - right-sidebar

---
<p style="text-align: justify;">
  This is my blog. I’m usually writing about Software Development and Tech news, but other stuff does creep in from time to time.
</p><div class="contactformgenerator\_wrapper cfg\_wrapper\_animation\_state\_1 cfg\_form\_1 cfg\_icon\_1 cfg\_sections\_template\_1" style="width: 100% !important" focus\_anim\_enabled="0" error\_anim\_enabled="0" scrollbar\_popup\_style="inset-2-dark" scrollbar\_content\_style="inset-2-dark"> 

<div class="contactformgenerator_wrapper_inner">
  <div class="contactformgenerator_loading_wrapper">
    <table style="border: none;width: 100%;height: 100%">
      <tr>
        <td align="center" style="text-align: center;" valign="middle">
          <img src="http://www.iuliantabara.com/wp-content/plugins/contact-form-generator/includes//assets/images/ajax-loader.gif" />
        </td>
      </tr>
    </table>
  </div>
  
  <div class="contactformgenerator_header cfg_header_animation_state_1">
    <div class="contactformgenerator_title cfg_font_effect_none">
      Contact me
    </div>
    
    <div class="contactformgenerator_pre_text cfg_font_effect_none">
      Feel free to contact me if you have any questions.
    </div>
  </div>
</div></div>