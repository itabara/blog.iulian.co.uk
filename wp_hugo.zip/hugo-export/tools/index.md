---
title: Tools
author: Iulian
type: page
date: 2016-01-05T17:09:00+00:00

---
Below the list of tools that I&#8217;ve worked with and allows me to save time.

## IDEs:

  * Visual Studio 2015 &#8211; Community Edition
  * WebStorm

## Text Editors:

  * Atom
  * Sublime 3

## Infrastructure

  * Docker
  * Vagrant
  * Ansible

## noSQL:

  * MongoDB

## Versioning:

  * Git / Stash &#8211; atlassian / Github

## CI

  * Atlassian Bamboo
  * Jenkins
  * TeamCity

## Shell tools:

  * <a href="https://conemu.github.io/" target="_blank">https://conemu.github.io</a>
  * <a href="https://mridgers.github.io/clink/" target="_blank">https://mridgers.github.io/clink/</a>

## Networking & proxies:

  * [Wireshark][1]
  * [Burp Suite][2]

## Data generator:

  * <a href="https://www.mockaroo.com/" target="_blank">https://www.mockaroo.com/</a>

 [1]: https://www.wireshark.org/
 [2]: https://portswigger.net/burp/